package com.amrita.jpl.cys21025.ex;

import java.util.*;

/**
 * class vehicle
 */
class Vehicle
{
    int t = 0;
    /**
     * function to start vehicle
     * @param
     */
    void start()
    {
        int t = 1;
        System.out.println("[Vehicle] started.");
    }
    /**
     * function to stop vehicle
     * @param
     */
    void stop()
    {
        t = 0;
        System.out.println("[Vehicle] stopped.");
    }
}

/**
 * class extends from vehicle
 */
class Car extends Vehicle
{
    String model;
    int year,wheel;
    /**
     * constructor of class
     * param a model name
     * b year
     * c wheels
     */
    Car(String a, int b, int c)
    {
        model = a;
        year = b;
        wheel = c;
        System.out.println("Car Instantiated with Parameter "+a+", "+b+", "+c);
    }
    /**
     * constructor of class
     * param
     */
    void drive(int gp)
    {
        if(t == 0)
        {
            System.out.println("Cannot drive. Start the car first.");
        }
        else
        {
            System.out.println("Driving the car in gear position: "+gp);
        }
    }
}

/**
 *class extends from vehicle
 */
class Bike extends Vehicle
{
    String name;
    int year, gear;
    /**
     * constructor of class
     * param a model name
     * b year
     * c gears
     */
    Bike(String a, int b, int c)
    {
        name = a;
        year = b;
        gear = c;
        System.out.println("Bike Instantiated with Parameter "+a+", "+b+", "+c);
    }
    /**
     * prints on which speed vehicle is pedaling
     * param speed
     */
    void pedal(int gp)
    {
        if(t == 0)
        {
            System.out.println("Cannot drive. Start the bike first.");
        }
        else
        {
            System.out.println("Pedaling the bike at speed: "+gp);
        }
    }
}


public class main
{
    /**
     * main method
     * @param args
     */
    public static void main(String[] args)
    {
        Car c = new Car("Jaguar XF",2022, 4);
        c.start();
        c.drive(3);
        c.stop();

        Bike b = new Bike("Giant",2021, 18);
        b.start();
        b.pedal(10);
        b.stop();
    }
}