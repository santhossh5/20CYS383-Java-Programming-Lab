package com.amrita.jpl.cys21025.ex;
import java.io.*;
import java.net.*;

abstract class FileTransfer {
    abstract void sendFile(String filename);
    abstract void saveFile(byte[] fileData, String filename);
}

interface FileTransferListener {
    void onFileSent(String filename);
    void onFileSaved(String filename);
}

class FileTransferClient extends FileTransfer implements FileTransferListener {
    private static final int SERVER_PORT = 1234;
    private static final String SERVER_ADDRESS = "localhost";

    @Override
    void sendFile(String filename) {
        try {
            File file = new File(filename);
            byte[] fileData = new byte[(int) file.length()];
            FileInputStream fileInputStream = new FileInputStream(file);
            BufferedInputStream bufferedInputStream = new BufferedInputStream(fileInputStream);
            bufferedInputStream.read(fileData, 0, fileData.length);

            Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
            OutputStream outputStream = socket.getOutputStream();

            // Sending file name and data to server
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
            dataOutputStream.writeUTF(file.getName());
            dataOutputStream.writeInt(fileData.length);
            dataOutputStream.write(fileData, 0, fileData.length);
            dataOutputStream.flush();

            // Close connections
            fileInputStream.close();
            bufferedInputStream.close();
            dataOutputStream.close();
            socket.close();

            onFileSent(filename); // Notify file sent
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void saveFile(byte[] fileData, String filename) {
        // This method is not used in the client class
    }

    @Override
    public void onFileSent(String filename) {
        System.out.println("File sent: " + filename);
    }

    @Override
    public void onFileSaved(String filename) {
        // This method is not used in the client class
    }
}

class FileTransferServer extends FileTransfer implements FileTransferListener {
    private static final int SERVER_PORT = 1234;

    @Override
    void saveFile(byte[] fileData, String filename) {
        try (FileOutputStream fileOutputStream = new FileOutputStream(filename)) {
            fileOutputStream.write(fileData);
            onFileSaved(filename);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void sendFile(String filename) {
        // Not used
    }

    @Override
    public void onFileSent(String filename) {
        // Not used
    }

    @Override
    public void onFileSaved(String filename) {
        System.out.println("File saved on the server: " + filename);
    }

    void start() {
        try (ServerSocket serverSocket = new ServerSocket(SERVER_PORT)) {
            System.out.println("Server started. Listening on port: " + SERVER_PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ClientHandler implements Runnable {
        private Socket clientSocket;

        ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (InputStream inputStream = clientSocket.getInputStream(); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {

                byte[] buffer = new byte[4096];
                int bytesRead;

                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }

                saveFile(outputStream.toByteArray(), "received_file.txt");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

public class FTPServerClient {
    public static void main(String[] args) {
        FileTransferClient client = new FileTransferClient();
        FileTransferServer server = new FileTransferServer();

        server.start();
        client.sendFile("C:/Users/santhosh/Desktop/a.txt");
    }
}
