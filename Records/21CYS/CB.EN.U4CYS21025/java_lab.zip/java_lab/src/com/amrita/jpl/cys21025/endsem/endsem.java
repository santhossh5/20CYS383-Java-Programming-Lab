package com.amrita.jpl.cys21025.endsem;
/**
 * * @author K S Santhossh CB.EN.U4CYS21025
 * End Semester Lab Evaluation.
 */
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.dnd.DropTarget;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 * Main class containg main function
 */
public class endsem {
    private JFrame frame;
    private JTable table;
    private DefaultTableModel tableModel;
    private List<files> files;

    /**
     * constructor of the class
     */
    public endsem() {
        files = new ArrayList<>();
        initialize();
    }

    /**
     * method to create the GUI
     * param none
     */
    private void initialize() {
        frame = new JFrame("21UCYS End Semester Assignment File Manager");
        frame.setBounds(100, 100, 600, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel Panel = new JPanel();

       Panel.setLayout(new BorderLayout());

        JPanel northPanel = new JPanel(new GridLayout(1, 6));
        northPanel.add(new JLabel("File Name"));
        northPanel.add(new JTextArea());
        northPanel.add(new JLabel("File Size"));
        northPanel.add(new JTextArea());
        northPanel.add(new JLabel("File Type"));
        String[] items = {"Document", "Image", "Video"};
        JComboBox<String> dropdown = new JComboBox<>(items);
        dropdown.setBounds(50, 50, 150, 30);

        northPanel.add(dropdown);

        // Create the table with columns
        tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("File Type");
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Create buttons
        JPanel buttonPanel = new JPanel();
        frame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        JButton addButton = new JButton("Add File");
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAddfileDialog();
            }
        });
        buttonPanel.add(addButton);


        JButton deleteButton = new JButton("Delete File");
        deleteButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    files.remove(selectedRow);
                    tableModel.removeRow(selectedRow);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please select a file to delete.");
                }
            }
        });
        buttonPanel.add(deleteButton);

        JButton editButton = new JButton("Refresh");

        buttonPanel.add(editButton);
        Panel.add(northPanel,BorderLayout.NORTH);
        frame.add(Panel);
        frame.setVisible(true);
    }

    /**
     * method to perform action on clicking add file
     * adds file information displays in table
     */
    private void showAddfileDialog() {
        JTextField nameField = new JTextField();
        JTextField phoneNumberField = new JTextField();
        JTextField emailField = new JTextField();

        JPanel panel = new JPanel(new GridLayout(0, 1));
        panel.add(new JLabel("Enter Document type:"));
        panel.add(nameField);

        int result = JOptionPane.showConfirmDialog(frame, panel, "Add File", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            String name = nameField.getText().trim();
            String phoneNumber = phoneNumberField.getText().trim();
            String email = emailField.getText().trim();

             {
                files f = new files(name, phoneNumber, email);
                files.add(f);
                tableModel.addRow(new Object[]{name, phoneNumber, email});
            }
        }
    }

    /**
     * Main method to drive the code
     * @param args
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new endsem();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}

/**
 * class file to manage files
 */
class files {
    private String fname;
    private String fsize;
    private String ftype;

    public files(String name, String phoneNumber, String email) {
        this.fname = name;
        this.fsize = phoneNumber;
        this.ftype = email;
    }

    public String getName() {
        return fname;
    }

    public void setName(String name) {
        this.fname = name;
    }

    public String getPhoneNumber() {
        return fsize;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.fsize = phoneNumber;
    }

    public String getEmail() {
        return ftype;
    }

    public void setEmail(String email) {
        this.ftype = email;
    }
}