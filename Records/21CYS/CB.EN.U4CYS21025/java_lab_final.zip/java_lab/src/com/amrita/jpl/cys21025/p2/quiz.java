package com.amrita.jpl.cys21025.p2;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
/**
 * * @author K S Santhossh CB.EN.U4CYS21025
 */
// Abstract class QuizGame
abstract class QuizGame {
    // Method to start the game
    void startGame() {
        // Handle overall flow of the game
        askQuestion();
        evaluateAnswer("Sample answer");
    }

    // Abstract method to ask a question
    abstract String askQuestion();

    // Abstract method to evaluate an answer
    abstract void evaluateAnswer(String answer);
}

// Interface QuizGameListener
interface QuizGameListener {
    void onQuestionAsked(String question);
    void onAnswerEvaluated(boolean isCorrect);
}

class QuizGameServer extends QuizGame implements QuizGameListener {
    /**
     * The main method is the entry point of the program.
     * It listens for incoming connections, receives messages, and prints them to the console.
     */

    static int ques = 1;
    int mark = 0;
    /**
     * This method should start the quiz game and handle the overall
     * flow of the game.
     */
    void startGame()
    {
        Scanner input = new Scanner(System.in);
        try {
            // Create a server socket on port 2444
            ServerSocket ss = new ServerSocket(12345);

            // Wait for a client to establish a connection
            Socket s = ss.accept();

            // Create a DataInputStream to receive messages from the client
            DataInputStream dis = new DataInputStream(s.getInputStream());

            // Create a DataOutputStream to send messages to the client.
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            String str;
            String msg = "0";
            System.out.println("Receiving Messages from the client.");
            int i = 1;
            // Read the message from the client using Do-While loop.
            do{
                if(!msg.equals("exit")) { // checks if the server reply is not empty then proceeds to receive the msg from client.
                    i++;
                    /*str = dis.readUTF();
                    System.out.println("Client Message: " + str);
                    evaluateAnswer(str);
                    System.out.print("server sending message: ");
                    msg = askQuestion();
                    dout.writeUTF(msg);
                    dout.flush();*/
                    msg = askQuestion();
                    dout.writeUTF(msg);
                    dout.flush();
                    str = dis.readUTF();
                    System.out.println("Client Message: " + str);
                    evaluateAnswer(str);

                }
            }
            while(true);


            // Close the server socket
            //ss.close(); // server socket is not closed even after the client socket is closed and it's always listening.
        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
    public void onQuestionAsked(String question)
    {}
    public void onAnswerEvaluated(boolean iscorrect)
    {
        mark++;
    }
    /**
     * asks question to the client
     */
    String askQuestion()
    {
        String a = "1+"+Integer.toString(ques);
        ques+=1;
        return a;
    }

    void evaluateAnswer(String answer)
    {
        if(answer == "2")
        {
            System.out.println("Correct");
            onAnswerEvaluated(true);
        }
        else {
            System.out.println("Wrong");
        }
    }
    QuizGameServer() throws IOException {

    }
}

class QuizGameClient extends QuizGame {
    /**
     * The main method is the entry point of the program.
     * It establishes a connection to the server, sends a message, and closes the connectio
     */
    void startGame()
    {
        try {
            // Create a socket and connect to the server at "localhost" on port 2444
            Socket s = new Socket("localhost", 12345);

            // Create a DataOutputStream to send messages to the server
            DataOutputStream dout = new DataOutputStream(s.getOutputStream());
            Scanner input = new Scanner(System.in);

            // Create a DataInputStream to receive messages from the server.
            DataInputStream din = new DataInputStream(s.getInputStream());
            System.out.println("Messaging to the Server.");
            // Sending messages to the server by using the Do-While Loop
            String msg;
            int i=1;
            do {
                msg = din.readUTF(); // reading the message from the input stream of server.
                System.out.println("Server: " + msg);
                System.out.print("client sending message: ");
                String str = input.nextLine();
                dout.writeUTF(str); // sending the message to output stream
                dout.flush();

                i++;
                if(!msg.equals("exit")) {
                    System.out.println("Connection closed.");
                    dout.close();
                    din.close();
                    s.close(); // Close the output stream and the socket if the server sends exit.
                }
            } while (!msg.equals("exit"));

        } catch (IOException e) {
            System.out.println("An error occurred: " + e);
        }
    }
    public void onQuestionAsked(String question)
    {}
    public void onAnswerEvaluated(boolean iscorrect)
    {}
    String askQuestion()
    {
        return "0";
    }

    void evaluateAnswer(String answer)
    {}

    public QuizGameClient()
    {
    }
}


public class quiz
{
    /**
     * main method to call server and client
     * using threads to call server and client alternatively
     */
    public static void main(String args[])
    {
        int port = 1234;
        String host = "localhost";

        try {
            // Start the server in a separate thread
            Thread serverThread = new Thread(() -> {
                try {
                    QuizGameServer s = new QuizGameServer();
                    s.startGame();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            });
            serverThread.start();

            // Wait for the server to start
            Thread.sleep(1000);

            // Start the client
            QuizGameClient c = new QuizGameClient();
            c.startGame();

            // Wait for the server thread to finish
            serverThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
