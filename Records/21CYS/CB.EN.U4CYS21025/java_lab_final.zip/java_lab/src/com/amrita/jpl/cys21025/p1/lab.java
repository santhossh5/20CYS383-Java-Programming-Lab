package com.amrita.jpl.cys21025.p1;

import java.util.*;
import java.util.Scanner;
import java.math.*;

public class lab {
    /**
     * function to return reverse of a given number
     * @param n number to be reversed
     * @return reversed number
     */
    public int rev(int n)
    {
        int r=0;
        while(n>0)
        {
            r = r*10+(n%10);
            n/=10;
        }
        return r;
    }

    /**
     * function to return largest of three numbers
     * @param a first number
     * @param b second number
     * @param c third number
     * @return largest number of three
     */
    public int largest(int a, int b, int c)
    {
        if(a>b && a>c)
        {
            return a;
        }
        else if (b>c)
        {
            return b;
        }
        else
        {
            return c;
        }
    }

    /**
     * function to check whether the giver number is perfect square
     * @param n number to be checked
     */
    public void per_sq(int n)
    {
        double a = Math.sqrt(n);
        int b = (int) a;
        if(a-b > 0)
        {
            System.out.println("It is not a perfect square");
        }
        else
        {
            System.out.println("It is a perfect square");
        }
    }

    /**
     * function to check whether the given number is prime or not
     * @param n number to be checked
     */
    public void prime(int n)
    {
        for(int i=2 ; i<=(n/2) ; i++)
        {
            if(n%i == 0)
            {
                System.out.println("It is not a prime.");
                return;
            }
        }
        System.out.println("It is a prime.");
    }

    /**
     * main function to call all functions
     * @param args
     */
    public static void main(String args[])
    {
        System.out.println("1. Reverse of a number (reverse num), \n" +
                "2. Largest of three numbers (large3num), \n" +
                "3. Perfect Square (perfect square check), \n" +
                "4. Prime Test (prime test)\n");
        int choice;
        Scanner sc = new Scanner(System.in);
        choice = sc.nextInt();
        int n,a,b,c;
        lab l = new lab();
        switch (choice)
        {
            case 1:
                System.out.print("Enter num to be reversed : ");
                n = sc.nextInt();
                System.out.println("Reversed number : " + l.rev(n));
                break;
            case 2:
                System.out.println("Enter three numbers : ");
                a = sc.nextInt();
                b = sc.nextInt();
                c = sc.nextInt();
                System.out.println("Largest number : " + l.largest(a,b,c));
                break;
            case 3:
                System.out.println("Enter the number : ");
                n = sc.nextInt();
                l.per_sq(n);
                break;
            case 4:
                System.out.println("Enter the number : ");
                n = sc.nextInt();
                l.prime(n);
                break;
            default:
                System.out.println("Entered choice is wrong\n");
                break;
        }
    }
}