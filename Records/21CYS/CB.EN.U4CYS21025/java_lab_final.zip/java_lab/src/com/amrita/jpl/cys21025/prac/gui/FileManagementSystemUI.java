package com.amrita.jpl.cys21025.prac.gui;

import javax.swing.*;
import java.util.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;

/**
 * The abstract File class represents a generic file with a name and size.
 */
abstract class File {
    private String fileName;
    private long fileSize;

    /**
     * Creates a new instance of the File class with the specified name and size.
     *
     * @param fileName the name of the file
     * @param fileSize the size of the file
     */
    public File(String fileName, long fileSize) {
        this.fileName = fileName;
        this.fileSize = fileSize;
    }

    public String getFileName() {
        return fileName;
    }

    public long getFileSize() {
        return fileSize;
    }

    /**
     * Displays the details of the file.
     */
    public void displayFileDetails() {

    }
}

/**
 * The Document class represents a document file, extending the File class.
 */
class Document extends File {
    private String documentType;

    /**
     * Creates a new instance of the Document class with the specified name, size, and document type.
     *
     * @param fileName      the name of the document file
     * @param fileSize      the size of the document file
     * @param documentType  the type of the document file
     */
    public Document(String fileName, long fileSize, String documentType) {
        super(fileName, fileSize);
        this.documentType = documentType;
    }

    public String getDocumentType() {
        return documentType;
    }
}

/**
 * The Image class represents an image file, extending the File class.
 */
class Image extends File {
    private String resolution;

    /**
     * Creates a new instance of the Image class with the specified name, size, and resolution.
     *
     * @param fileName    the name of the image file
     * @param fileSize    the size of the image file
     * @param resolution  the resolution of the image file
     */
    public Image(String fileName, long fileSize, String resolution) {
        super(fileName, fileSize);
        this.resolution = resolution;
    }

    public String getResolution() {
        return resolution;
    }
}

/**
 * The Video class represents a video file, extending the File class.
 */
class Video extends File {
    private String duration;

    /**
     * Creates a new instance of the Video class with the specified name, size, and duration.
     *
     * @param fileName    the name of the video file
     * @param fileSize    the size of the video file
     * @param duration    the duration of the video file
     */
    public Video(String fileName, long fileSize, String duration) {
        super(fileName, fileSize);
        this.duration = duration;
    }

    public String getDuration() {
        return duration;
    }
}

/**
 * The FileManager interface defines operations for managing files.
 */
interface FileManager {
    void addFile(File file);
    void deleteFile(String fileName);
    void saveToFile();
    void loadFromFile();
    ArrayList<File> getFiles();
}

/**
 * The FileManagerImpl class implements the FileManager interface.
 */
class FileManagerImpl implements FileManager {
    ArrayList<File> files;

    public FileManagerImpl() {
        files = new ArrayList<>();
    }

    @Override
    public void addFile(File file) {
        files.add(file);
    }

    @Override
    public void deleteFile(String fileName) {
        for (File file : files) {
            if (file.getFileName().equals(fileName)) {
                files.remove(file);
            }
        }
    }

    @Override
    public void saveToFile() {
        try {
            FileWriter writer = new FileWriter("filedetails.txt");
            for (File file : files) {
                writer.write(file.getFileName() + " " + file.getFileSize() + " ");
            }

        } catch (IOException e) {
            System.out.println("File could not be opened/created. Check directory permissions.");
        }
    }

    @Override
    public void loadFromFile() {

    }

    @Override
    public ArrayList<File> getFiles() {
        return files;
    }
}

/**
 * The FileManagementSystemUI class represents the user interface for the file management system.
 */
public class FileManagementSystemUI {
    FileManager fileManager;
    private DefaultTableModel tableModel;

    /**
     * Creates a new instance of the FileManagementSystemUI class.
     */
    public void FileManagementSystemUI() {
        fileManager = new FileManagerImpl();
        tableModel = new DefaultTableModel();
        tableModel.addColumn("File Name");
        tableModel.addColumn("File Size");
        tableModel.addColumn("Type/Resolution/Duration");
    }

    /**
     * Sets up the graphical user interface for the file management system.
     */
    public void GUI() {
        JFrame frame = new JFrame("21UCYS End Semester Assignment File Manager");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(1, 6));
        JLabel fileName = new JLabel("File Name: ");
        JTextField nameinput = new JTextField();
        JLabel fileSize = new JLabel("File Size: ");
        JTextField sizeinput = new JTextField();
        String[] items = {"Document", "Image", "Video"};
        JComboBox<String> dropdown = new JComboBox<>(items);
        dropdown.setBounds(50, 50, 150, 30);

        frame.add(dropdown);

        inputPanel.add(fileName);
        inputPanel.add(nameinput);
        inputPanel.add(fileSize);
        inputPanel.add(sizeinput);

        JTable fileTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(fileTable);
        frame.add(scrollPane, BorderLayout.CENTER);

        JButton addButton = new JButton("Add File");
        JButton deleteButton = new JButton("Delete File");
        JButton displayButton = new JButton("Display All Files");
        JButton saveButton = new JButton("Save to File");
        JButton loadButton = new JButton("Load from File");
        JButton refreshButton = new JButton("Refresh");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(displayButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(loadButton);
        buttonPanel.add(refreshButton);

        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.setLayout(null);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                FileManagementSystemUI systemUI = new FileManagementSystemUI();
                systemUI.GUI();
            }
        });
    }
}
